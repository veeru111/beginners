package com.ts.hellocontroller;

import org.springframework.stereotype.Service;

@Service
public class Wish {
	
public Wish() {
		super();
	}

public void showWish() {
	System.out.println("Hi.....This is wish method...");
}
}
