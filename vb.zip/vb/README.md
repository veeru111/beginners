Tutorial 1
==========

In this first tutorial we get up and running with a basic web server that
serves any files in the local directory.

How to run
-------------

* Install Go
    * http://golang.org/doc/install
* Download this project from github and unzip
    * https://github.com/jakecoffman/golang-webapp-tutorial/archive/master.zip
* Open a command window and `cd` to the tutorial_1 directory
* Type `go run main.go` to start the server
* Open a web browser and go to http://localhost/

If you get a message that says "It works!" then it's working.
