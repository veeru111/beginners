package main

import (
	"fmt"
	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
	"html/template"
	"log"
	"net/http"
)

type USER struct {
	Id        bson.ObjectId `bson:"_id,omitempty"`
	Useremail string        `bson:"Useremail" json:"Useremail,omitempty"`
}

func login(w http.ResponseWriter, r *http.Request) {
	fmt.Println("method:", r.Method)
	if r.Method == "GET" {
		t, _ := template.ParseFiles("index.html")
		t.Execute(w, nil)
	} else {
		//connection with mongodb
		session, err := mgo.Dial("localhost:27017")
		if err != nil {
			panic(err)
		}
		defer session.Close()
		session.SetMode(mgo.Monotonic, true)

		r.ParseForm()

		c := session.DB("test").C("user")
		doc := USER{
			Useremail: r.Form["useremail"][0],
		}
		err = c.Insert(doc)
		if err != nil {
			panic(err)
		}

		str := r.Form["useremail"][0]
		result := USER{}
		err = c.Find(bson.M{"Useremail": str}).One(&result)
		if err != nil {
			log.Fatal(err)
		}

		fmt.Fprintln(w, result.Useremail)
		fmt.Fprintln(w, result.Id.Hex())

	}

}

func main() {

	http.HandleFunc("/login", login)
	err := http.ListenAndServe(":9090", nil)
	if err != nil {
		log.Fatal("ListenAndServe: ", err)
	}
}
